function convertTimezoneToReadable(timezone) {
    return timezone;
}

export {convertTimezoneToReadable};